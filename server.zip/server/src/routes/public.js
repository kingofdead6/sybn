import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { asyncHandler } from '../middleware/errorHandler.js';
import { ok, fail, paginate } from '../utils/apiResponse.js';
import {
  Program,
  Category,
  Course,
  CourseEnrollment,
  TeamMember,
  Story,
  Forum,
  Product,
  ProductRequest,
  StoreExample,
  Resource,
  Certificate,
  CertificateRequest,
  ForumRegistration,
  ProposalRequest,
  Enquiry,
  Setting,
} from '../models/index.js';
import { requireAuth, optionalAuth } from '../middleware/auth.js';
import { notifyAdmin } from '../utils/mailer.js';
import { notifyWhatsApp } from '../utils/whatsapp.js';
import { cleanFormAnswers } from '../utils/formAnswers.js';

const router = Router();

// ---- Programs ----
router.get('/programs', asyncHandler(async (req, res) => {
  // `parent` is populated because the nav and the cards build a nested
  // program's address from its parent's slug, not its id.
  const items = await Program.find({ published: true })
    .populate({ path: 'parent', select: 'slug title code' })
    .sort('order');
  ok(res, items);
}));

/** The fields a card needs to stand for another program and link to it. */
const PROGRAM_CARD_FIELDS = 'slug title code image audience parent published';

/**
 * A program plus the programs nested beneath it.
 *
 * `children` is attached rather than stored, so it always reflects what is
 * actually published right now. `parent` is populated so a child page can name
 * and link back to the program it belongs to.
 */
async function findProgramWithChildren(slug) {
  const item = await Program.findOne({ slug, published: true })
    .populate({ path: 'modules.program', select: PROGRAM_CARD_FIELDS })
    .populate({ path: 'parent', select: PROGRAM_CARD_FIELDS });
  if (!item) return null;

  const children = await Program.find({ parent: item._id, published: true })
    .select(PROGRAM_CARD_FIELDS)
    .sort('order');

  return { ...item.toObject(), children };
}

router.get('/programs/:slug', asyncHandler(async (req, res) => {
  const item = await findProgramWithChildren(req.params.slug);
  if (!item) return fail(res, 404, 'Program not found');
  ok(res, item);
}));

/**
 * A nested program. The parent slug is verified rather than decorative, so a
 * mismatched pair 404s instead of rendering a child under the wrong parent.
 */
router.get('/programs/:parentSlug/:slug', asyncHandler(async (req, res) => {
  const item = await findProgramWithChildren(req.params.slug);
  if (!item) return fail(res, 404, 'Program not found');
  if (item.parent?.slug !== req.params.parentSlug) {
    return fail(res, 404, 'Program not found under this parent');
  }
  ok(res, item);
}));

// ---- Categories ----
router.get('/categories', asyncHandler(async (req, res) => {
  const items = await Category.find().sort('order');
  ok(res, items);
}));

router.get('/categories/:slug', asyncHandler(async (req, res) => {
  const item = await Category.findOne({ slug: req.params.slug });
  if (!item) return fail(res, 404, 'Category not found');
  ok(res, item);
}));

// ---- Courses (the specialized-course catalogue behind the categories) ----
router.get('/courses', asyncHandler(async (req, res) => {
  const filter = { published: true };

  // `category` accepts one or more category slugs (the filter sidebar).
  const slugs = [].concat(req.query.category || []).filter(Boolean);
  if (slugs.length) {
    const cats = await Category.find({ slug: { $in: slugs } }).select('_id');
    // An unknown slug must yield nothing rather than silently ignoring the filter.
    filter.category = { $in: cats.map((c) => c._id) };
  }

  if (req.query.q) {
    const rx = new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    filter.$or = [{ 'title.ar': rx }, { 'title.en': rx }, { code: rx }];
  }

  const SORTS = {
    newest: { releasedAt: -1, createdAt: -1 },
    oldest: { releasedAt: 1, createdAt: 1 },
    rating: { rating: -1, createdAt: -1 },
    order: { order: 1, createdAt: -1 },
  };
  const sort = SORTS[req.query.sort] || SORTS.newest;

  const items = await Course.find(filter).sort(sort).populate('category', 'slug title');
  ok(res, items);
}));

router.get('/courses/:slug', asyncHandler(async (req, res) => {
  const item = await Course.findOne({ slug: req.params.slug, published: true })
    .populate('category', 'slug title');
  if (!item) return fail(res, 404, 'Course not found');
  // With a capacity, how many seats are taken, so the page can say "full".
  const seatsTaken = item.capacity
    ? await CourseEnrollment.countDocuments({ course: item._id, status: { $in: ['accepted', 'completed'] } })
    : 0;
  ok(res, { ...item.toObject(), seatsTaken });
}));

// ---- Team / network ----
router.get('/team', asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.region) filter.region = req.query.region;
  const items = await TeamMember.find(filter).sort('order');
  ok(res, items);
}));

router.get('/team/:slug', asyncHandler(async (req, res) => {
  const item = await TeamMember.findOne({ slug: req.params.slug });
  if (!item) return fail(res, 404, 'Team member not found');
  ok(res, item);
}));

// ---- Stories ----
router.get('/stories', asyncHandler(async (req, res) => {
  const { page, limit, skip } = paginate(req.query);
  const filter = {};
  if (req.query.category && req.query.category !== 'all') filter.category = req.query.category;
  const [items, total] = await Promise.all([
    Story.find(filter).sort('order').skip(skip).limit(limit),
    Story.countDocuments(filter),
  ]);
  ok(res, items, { meta: { page, limit, total } });
}));

// ---- Forums ----
router.get('/forums', asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  const items = await Forum.find(filter).sort('startDate');
  ok(res, items);
}));

// ---- Products ----
router.get('/products', asyncHandler(async (req, res) => {
  const { page, limit, skip } = paginate(req.query);
  // One general catalogue: everything published is listed, unfiltered.
  const filter = { published: true };
  const [items, total] = await Promise.all([
    Product.find(filter).sort('-createdAt').skip(skip).limit(limit),
    Product.countDocuments(filter),
  ]);
  ok(res, items, { meta: { page, limit, total } });
}));

// ---- Store examples (showcase of graduate storefronts) ----
router.get('/store-examples', asyncHandler(async (req, res) => {
  const items = await StoreExample.find({ published: true }).sort('order');
  ok(res, items);
}));

// ---- Key resources ----
router.get('/resources', asyncHandler(async (req, res) => {
  const items = await Resource.find({ published: true }).sort('order');
  ok(res, items);
}));

router.get('/resources/:slug', asyncHandler(async (req, res) => {
  const item = await Resource.findOne({ slug: req.params.slug, published: true });
  if (!item) return fail(res, 404, 'Resource not found');
  ok(res, item);
}));

// ---- Certificate verification (rate limited) ----
const verifyLimiter = rateLimit({ windowMs: 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false });

router.post('/verify-certificate', verifyLimiter, asyncHandler(async (req, res) => {
  const { number } = req.body;
  if (!number || typeof number !== 'string') return fail(res, 400, 'Enter a certificate number');
  const cert = await Certificate.findOne({ number: number.trim() }).populate('program').populate('course');
  if (!cert) return fail(res, 404, 'No certificate found with this number. Double-check the number and try again.');
  ok(res, {
    number: cert.number,
    holderName: cert.holderName,
    // A course certificate has no program; the course stands in its place so
    // the page always has a title to show.
    program: cert.program || cert.course,
    issuedAt: cert.issuedAt,
    status: cert.status,
  });
}));

// ---- Form submissions ----
router.post('/certificate-requests', optionalAuth, asyncHandler(async (req, res) => {
  const { fullName, email, whatsapp, country, program, course, wantsForums, answers } = req.body;
  if (!program && !course) return fail(res, 400, 'A program or a course is required');
  // A course certificate is requested from the student's account once the
  // admin has marked the course done — not from this open form.
  if (course) {
    return fail(res, 400, 'Course certificates are requested from your account after completing the course');
  }

  // Only fields the owning program/course actually declares are stored, so a
  // client cannot inflate the document with arbitrary keys.
  const subject = program
    ? await Program.findOne({ _id: program, published: true })
    : await Course.findOne({ _id: course, published: true });
  if (!subject) return fail(res, 404, program ? 'Program not found' : 'Course not found');

  let clean;
  try {
    clean = cleanFormAnswers(subject.formFields || [], answers);
  } catch (err) {
    return fail(res, err.status || 400, err.message);
  }

  // Never trust status/certificate from the client. When the
  // requester is signed in, the account's own email is authoritative — the
  // request must reach the person who made it, not an address they typed.
  const item = await CertificateRequest.create({
    fullName,
    email: req.user?.email || email,
    whatsapp,
    country,
    user: req.user?._id,
    program: program || undefined,
    course: course || undefined,
    wantsForums: !!wantsForums,
    answers: clean,
  });
  notifyAdmin('New certificate request', `From: ${item.fullName} <${item.email}>`).catch(() => {});
  ok(res, item);
}));

router.post('/forum-registrations', optionalAuth, asyncHandler(async (req, res) => {
  // Atomic conditional increment: only succeeds while the forum is still open
  // and has a free seat, so two concurrent requests for the last seat can't
  // both win (the loser's filter simply matches zero documents). A
  // seatsTotal of 0 means "uncapped" and is always allowed through.
  const forum = await Forum.findOneAndUpdate(
    {
      _id: req.body.forum,
      status: 'open',
      $or: [{ seatsTotal: 0 }, { $expr: { $lt: ['$seatsTaken', '$seatsTotal'] } }],
    },
    { $inc: { seatsTaken: 1 } },
    { new: true }
  );
  if (!forum) return fail(res, 400, 'This forum is not open for registration', 'FORUM_NOT_OPEN');

  if (forum.seatsTotal && forum.seatsTaken >= forum.seatsTotal && forum.status !== 'full') {
    forum.status = 'full';
    await forum.save();
  }

  const item = await ForumRegistration.create({
    ...req.body,
    // As above: a signed-in registration belongs to that account's address.
    email: req.user?.email || req.body.email,
    user: req.user?._id,
  });
  notifyAdmin('New forum registration', `From: ${item.fullName} <${item.email}> for ${forum.month} ${forum.year}`).catch(() => {});
  ok(res, item);
}));

router.post('/proposal-requests', requireAuth, asyncHandler(async (req, res) => {
  const cert = await Certificate.findOne({ _id: req.body.certificate, user: req.user._id, status: 'valid' }).populate('program');
  if (!cert || cert.program?.slug !== 'generate-your-business-idea') {
    return fail(res, 403, 'A verified GYB certificate is required to submit this form');
  }
  const item = await ProposalRequest.create({ ...req.body, user: req.user._id });
  ok(res, item);
}));

router.post('/enquiries', asyncHandler(async (req, res) => {
  const item = await Enquiry.create(req.body);
  notifyAdmin('New enquiry', `From: ${item.name} <${item.email}>\n\n${item.message}`).catch(() => {});
  ok(res, item);
}));

// Visitors ask for a shop to be built; the admin reviews each request.
// Rate-limited because it is an unauthenticated write.
const productRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
});

router.post('/product-requests', productRequestLimiter, asyncHandler(async (req, res) => {
  // Whitelist: status, adminNote and product are admin-controlled, so a client
  // must not be able to submit a request that is already "approved".
  const { name, email, phone, itemTitle, itemDescription, budget, quantity } = req.body;
  const item = await ProductRequest.create({
    name,
    email,
    phone,
    itemTitle,
    itemDescription,
    budget,
    quantity,
  });
  notifyAdmin(
    'New store item request',
    `From: ${item.name} <${item.email}>\nItem: ${item.itemTitle}\n\n${item.itemDescription}`
  ).catch(() => {});

  // The team's WhatsApp numbers are all messaged at once. The result goes back
  // to the page, which falls back to opening WhatsApp itself when nothing
  // could be sent (no numbers configured, or every send failed).
  const whatsapp = await notifyWhatsApp(
    [
      '🛍️ New shop request',
      `Name: ${item.name}`,
      `Email: ${item.email}`,
      item.phone && `Phone: ${item.phone}`,
      `Shop: ${item.itemTitle}`,
      `Sells: ${item.itemDescription}`,
      item.budget && `Budget: ${item.budget}`,
    ]
      .filter(Boolean)
      .join('\n'),
  );

  ok(res, { ...item.toObject(), whatsappSent: whatsapp.sent });
}));

// ---- Settings (public read) ----
/**
 * Settings that must never leave the server. This route is unauthenticated —
 * anything it serves is readable by anyone — so records holding credentials
 * are refused here and read through the admin API instead.
 */
const PRIVATE_SETTINGS = new Set(['integrations']);

router.get('/settings/:key', asyncHandler(async (req, res) => {
  if (PRIVATE_SETTINGS.has(req.params.key)) return fail(res, 404, 'Setting not found');
  const item = await Setting.findOne({ key: req.params.key });
  if (!item) return fail(res, 404, 'Setting not found');
  ok(res, item.value);
}));

export default router;
